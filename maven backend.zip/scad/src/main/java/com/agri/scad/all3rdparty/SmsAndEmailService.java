package com.agri.scad.all3rdparty;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("smsemail")
public class SmsAndEmailService {

	@GET
	@Path("sms")
	@Consumes(MediaType.APPLICATION_JSON)
	public void sendSms(@QueryParam("MobNo")String mobNo, @QueryParam("Amount")double amount) {
		System.out.println("SMS: Rs. "+amount+" has been added to your " +mobNo+" account.");
	}
	
	@GET
	@Path("email")
	@Consumes(MediaType.APPLICATION_JSON)
	public void sendEmail(@QueryParam("CardNo")String cardNo, @QueryParam("Amount")String amount) {
		System.out.println("EMAIL: Your "+cardNo+ " card has been credited with Rs. "+amount);
	}
}
