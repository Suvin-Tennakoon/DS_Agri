package com.agri.scad.all3rdparty;

import java.util.ArrayList;

public class MobileBill {

	private String phoneNo;
	private double sixDigPin;
	private double currentValue;
	private double amount;

	public MobileBill() {
		super();
	}

	public MobileBill(String phoneNo, double sixDigPin, double currentValue, double amount) {
		super();
		this.phoneNo = phoneNo;
		this.sixDigPin = sixDigPin;
		this.currentValue = currentValue;
		this.amount = amount;
	}

	public MobileBill(String phoneNo, double sixDigPin, double currentValue) {
		super();
		this.phoneNo = phoneNo;
		this.sixDigPin = sixDigPin;
		this.currentValue = currentValue;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public double getSixDigPin() {
		return sixDigPin;
	}

	public void setSixDigPin(double sixDigPin) {
		this.sixDigPin = sixDigPin;
	}

	public double getCurrentValue() {
		return currentValue;
	}

	public void setCurrentValue(double currentValue) {
		this.currentValue = currentValue;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}

class MobileBillDB {

	public static ArrayList<MobileBill> bills = new ArrayList<>();

	static {

		bills.add(new MobileBill("0112224448", 123456, 3500));
		bills.add(new MobileBill("0812254678", 654321, 500));
	}

}