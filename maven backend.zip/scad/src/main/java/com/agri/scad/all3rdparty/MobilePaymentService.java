package com.agri.scad.all3rdparty;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

@Path("mobilepayment")
public class MobilePaymentService {

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String billPayment(MobileBill mobileBill) {
		int index = 0;
		Client client;
		WebTarget target;

		for (MobileBill bill : MobileBillDB.bills) {

			if (bill.getPhoneNo().equals(mobileBill.getPhoneNo())
					&& (bill.getSixDigPin() == mobileBill.getSixDigPin())) {
				MobileBillDB.bills.get(index)
						.setAmount(MobileBillDB.bills.get(index).getAmount() + mobileBill.getAmount());

				client = ClientBuilder.newClient();
				target = client.target("http://localhost:8080/scad/thirdpt/smsemail/sms")
						.queryParam("MobNo", mobileBill.getPhoneNo()).queryParam("Amount", mobileBill.getAmount());
				
				target.request(MediaType.APPLICATION_JSON).get();

				return "Successfully Added to Monthly Bill";
			}
			index++;
		}
		return "Error While Adding to Monthly Bill";
	}
}
