package com.agri.scad.utils;

import com.agri.scad.datasource.Items;
import com.agri.scad.models.Item;

public class ItemUtil {

	public ItemUtil() {
		super();
	}

	public void addItem(int fId, String name, double price) {
		Items.items.add(new Item(Items.random.nextInt(100000), fId, name, price));
	}

	public void updateItem(int id, String name, double price) {
		// TODO Auto-generated method stub
		int index=0;
		for(Item it : Items.items) {
			
			if(it.getId() == id) {
				Items.items.get(index).setName(name);
				Items.items.get(index).setPrice(price);
			}
			index++;
		}
	}

	public void deleteItem(int id) {
		// TODO Auto-generated method stub
		for (Item it : Items.items) {
			if (it.getId() == id) {
				Items.items.remove(it);
			}
		}
	}
}
