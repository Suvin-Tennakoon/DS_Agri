package com.agri.scad.all3rdparty;

import java.util.ArrayList;

public class CreditCard {
	private String cardNo;
	private String cardHolder;
	private double amount;
	private int cvc;

	public CreditCard() {
		super();
	}

	public CreditCard(String cardNo, String cardHolder, double amount, int cvc) {
		super();
		this.cardNo = cardNo;
		this.cardHolder = cardHolder;
		this.amount = amount;
		this.cvc = cvc;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getCardHolder() {
		return cardHolder;
	}

	public void setCardHolder(String cardHolder) {
		this.cardHolder = cardHolder;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getCvc() {
		return cvc;
	}

	public void setCvc(int cvc) {
		this.cvc = cvc;
	}

}

class CreditCardsDB {
	public static ArrayList<CreditCard> cards = new ArrayList<>();

	static {
		cards.add(new CreditCard("1111222233334444", "Suvin", 3500, 123));
		cards.add(new CreditCard("1234123412341234", "Tony", 4500, 456));
	}
}
