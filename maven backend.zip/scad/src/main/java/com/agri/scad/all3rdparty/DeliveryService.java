package com.agri.scad.all3rdparty;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("delivery")
public class DeliveryService {

	@GET
	@Consumes(MediaType.APPLICATION_JSON)
	public void deliverItems(@QueryParam("Address")String address) {
		System.out.println("Your items will be delivered to "+address+" promptly.");
	}
}
