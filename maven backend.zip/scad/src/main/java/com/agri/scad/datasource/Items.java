package com.agri.scad.datasource;

import java.util.ArrayList;
import java.util.Random;

import com.agri.scad.models.Item;

public class Items {

	public static ArrayList <Item> items = new ArrayList<>();
	
	public static Random random = new Random();
	
	static {
		items.add(new Item(random.nextInt(100000), 1, "Soap", 100));
		items.add(new Item(random.nextInt(100000), 1, "Choco", 200));
	}
}
