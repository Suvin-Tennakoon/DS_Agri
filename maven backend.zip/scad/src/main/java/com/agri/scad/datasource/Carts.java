package com.agri.scad.datasource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import com.agri.scad.models.Cart;

public class Carts {

	public static ArrayList<Cart> carts = new ArrayList<>();
	
	public static Random random = new Random();
	
	static {
		HashMap<String, Integer> itmBundle = new HashMap<>();
		itmBundle.put("Bottle", 3);
		
		carts.add(new Cart(random.nextInt(100000), itmBundle));
	}
}
