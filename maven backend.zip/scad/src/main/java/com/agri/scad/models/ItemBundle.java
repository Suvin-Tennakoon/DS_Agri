package com.agri.scad.models;

public class ItemBundle {
	public String []items;
	public int []qty;

	public ItemBundle() {
		super();
	}
}
