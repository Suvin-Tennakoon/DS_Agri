package com.agri.scad.models;

import java.util.HashMap;

public class Cart {

	private int id;
	private HashMap<String, Integer> itmBundle = new HashMap<>();
		//to store item IDs and their quantities

	public Cart() {
		super();
	}

	public Cart(int id, HashMap<String, Integer> itmBundle) {
		super();
		this.id = id;
		this.itmBundle = itmBundle;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public HashMap<String, Integer> getItmBundle() {
		return itmBundle;
	}

	public void setItmBundle(HashMap<String, Integer> itmBundle) {
		this.itmBundle = itmBundle;
	}
}
