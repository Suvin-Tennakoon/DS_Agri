package com.agri.scad;

import java.util.ArrayList;

import com.agri.scad.datasource.Items;
import com.agri.scad.models.Item;
import com.agri.scad.utils.ItemUtil;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("items")
public class ItemService {
	
	ItemUtil itemUtil = new ItemUtil();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Item> getItems() {
		return Items.items;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addItem(Item item) {
		itemUtil.addItem(item.getfId(), item.getName(), item.getPrice());
	}
	
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("{id}")
    public void updateItem(@PathParam("id")int id, Item item) {
    	itemUtil.updateItem(id, item.getName(), item.getPrice());
    }
	
	@DELETE
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("{id}")
	public void deleteItem(@PathParam("id")int id) {
		itemUtil.deleteItem(id);
	}
}
