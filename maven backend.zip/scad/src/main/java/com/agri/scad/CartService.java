package com.agri.scad;

import java.util.ArrayList;

import com.agri.scad.datasource.Carts;
import com.agri.scad.models.Cart;
import com.agri.scad.models.ItemBundle;
import com.agri.scad.utils.CartUtil;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("carts")
public class CartService {

	CartUtil cartUtil = new CartUtil();

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public int addToCart(ItemBundle itemBundle) {		
		return cartUtil.addToCart(itemBundle);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Cart> getCarts() {
		return Carts.carts;
	}
}
