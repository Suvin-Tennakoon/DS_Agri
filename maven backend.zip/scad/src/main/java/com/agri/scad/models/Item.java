package com.agri.scad.models;

public class Item {

	private int id;
	private int fId;
	private String name;
	private double price;

	public Item() {
		super();
	}

	public Item(int id, int fId, String name, double price) {
		super();
		this.id = id;
		this.fId = fId;
		this.name = name;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getfId() {
		return fId;
	}

	public void setfId(int fId) {
		this.fId = fId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
