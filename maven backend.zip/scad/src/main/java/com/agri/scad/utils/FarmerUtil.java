package com.agri.scad.utils;

import com.agri.scad.datasource.Farmers;
import com.agri.scad.models.Farmer;

public class FarmerUtil {

	public FarmerUtil() {
		super();
	}
	
	public void addFarmer(String name, String mobile) {
		Farmers.farmers.add(new Farmer(Farmers.random.nextInt(100000), name, mobile));
	}
}
