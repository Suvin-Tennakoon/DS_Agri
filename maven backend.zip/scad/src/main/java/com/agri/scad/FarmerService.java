package com.agri.scad;

import java.util.ArrayList;

import com.agri.scad.datasource.Farmers;
import com.agri.scad.models.Farmer;
import com.agri.scad.utils.FarmerUtil;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("farmers")
public class FarmerService {
	
	FarmerUtil farmerUtil = new FarmerUtil();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<Farmer> getFarmers() {
        return Farmers.farmers;
    }
    
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public void addFarmer(Farmer farmer) {
    	farmerUtil.addFarmer(farmer.getName(), farmer.getMobile());
    }
    
}
