package com.agri.scad.utils;

import java.util.HashMap;

import com.agri.scad.datasource.Carts;
import com.agri.scad.models.Cart;
import com.agri.scad.models.ItemBundle;

public class CartUtil {

	public int addToCart(ItemBundle itmBundle) {
		// TODO Auto-generated method stub
		int cartId = Carts.random.nextInt(100000);
		HashMap<String, Integer> items = new HashMap<>();
		for(int i=0; i<itmBundle.items.length; i++) {
			items.put(itmBundle.items[i], itmBundle.qty[i]);
		}
		
		Carts.carts.add(new Cart(cartId, items));
		return cartId;
	}
}
