package com.agri.scad.all3rdparty;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

@Path("paymentgateway")
public class PaymentGatewayService {

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String makePayment(CreditCard cardModel) {
		Client client;
		WebTarget target;

		for (CreditCard cc : CreditCardsDB.cards) {
			if (cc.getCardNo().equals(cardModel.getCardNo()) && (cc.getCvc() == cardModel.getCvc())) {

				client = ClientBuilder.newClient();
				target = client.target("http://localhost:8080/scad/thirdpt/smsemail/email").queryParam("CardNo",
						cardModel.getCardNo()).queryParam("Amount", cardModel.getAmount());

				target.request(MediaType.APPLICATION_JSON).get();

				return "Payment Successfull !!!";
			}
		}
		return "Payment Unsuccessfull !!!";
	}
}
