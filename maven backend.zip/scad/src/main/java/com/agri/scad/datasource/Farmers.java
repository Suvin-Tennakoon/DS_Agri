package com.agri.scad.datasource;

import java.util.ArrayList;
import java.util.Random;

import com.agri.scad.models.Farmer;

public class Farmers {

	public static ArrayList<Farmer> farmers = new ArrayList<>();
	
	public static Random random = new Random();
	
	static {
		farmers.add(new Farmer(random.nextInt(100000), "Suvin", "1111"));
		farmers.add(new Farmer(random.nextInt(100000), "Mindula", "2222"));
	}
}
